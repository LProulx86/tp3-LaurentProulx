/* jshint node: true */
'use strict';

var express = require('express');

var routerBase = express.Router();

routerBase.get('/', function (req,res){
    res.statusCode = 200;
    res.setHeader('Conent-Type', 'text/plain; charset=utf-8');
    res.end('Tout fonctionne');
});

module.exports = routerBase;