/* jshint node: true */
'use strict';

module.exports = {
    'secret': 'Quber-leRipOff-!QUeBeCoiS!-de-Uber!',
};